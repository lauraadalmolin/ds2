class Comunicador
	attr_accessor :id_c, :nome, :programas, :imagem
end