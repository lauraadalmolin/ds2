class Programa
	attr_accessor :id_p, :id_c, :nome, :duracao, :dias_da_semana, :hora_inicio, :hora_fim, :imagem
end

