class Administrador
	attr_accessor :login, :senha
end