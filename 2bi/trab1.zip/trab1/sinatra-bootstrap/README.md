Hello!
====

This is a demonstrator for [Sinatra](http://www.sinatrarb.com/) and [Twitter Bootstrap](http://getbootstrap.com/). 

Use it as a boilerplate to start your own apps.

Go!
===

Download and run sinatra-bootstrap:

    git clone https://github.com/bootstrap-ruby/sinatra-bootstrap
    
    cd sinatra-bootstrap
    bundle install             # To install sinatra
    
    bundle exec ruby app.rb    # To run the sample
	
Then open [http://localhost:4567/](http://localhost:4567/)

What's next?
============
- Try the rerun gem to restart Sinatra automatically when you change source files: https://github.com/alexch/rerun
