class Aluno
	attr_accessor :nome, :matricula

	def initialize(nome="", matricula=0)
		@nome = nome	
		@matricula = matricula	
	end

end